"""Read-only publication of the user-selected tuning_v1 frozen results."""
from __future__ import annotations

import hashlib
import json
import shutil
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
CODE = Path('G:/aibot/AssertBert/eval/addEvalAll')
SOURCE = CODE / 'outputs_tuning_20261008'
sys.path.insert(0, str(CODE))
from common import load_config, newey_west
from evaluate import build_test_frame, evaluate_group, load_ff3
from tuning import verify_freeze, verify_fingerprints


def clean(value):
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(v) for v in value]
    if isinstance(value, np.generic):
        value = value.item()
    if isinstance(value, float) and not np.isfinite(value):
        return None
    return value


def write_json(path, value):
    path.write_text(json.dumps(clean(value), ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')


def rankings(metrics, weighting):
    values = {m: v[weighting]['gross'] for m, v in metrics.items()}
    checks = []
    for title, left, others in [('2 > 1','M2',['M1']), ('4 > 3','M4',['M3']),
                                 ('5 > 其余四组','M5',['M1','M2','M3','M4'])]:
        right = max(others, key=values.get)
        gap = values[left] - values[right]
        checks.append({'title':title, 'left':left, 'right':right, 'gap':gap, 'passed':bool(gap > 0)})
    return checks


def main():
    assert SOURCE.name == 'outputs_tuning_20261008'
    frozen, freeze_check = verify_freeze(SOURCE)
    config = load_config(CODE / 'config_tuning.yaml')
    join = pd.read_parquet(SOURCE / 'intersection.parquet')
    test = build_test_frame(join, pd.read_parquet(SOURCE / 'test_labels.parquet'))
    frames = {'test':test, 'validation':join.loc[join.split == 'validation'].reset_index(drop=True)}
    masks = {p:(join.split == p).to_numpy() for p in frames}
    factors = {'ff3':load_ff3(config['_paths']['three_factors'], 'P9714')}
    old_metrics = pd.read_csv(SOURCE / 'metrics.csv', float_precision='round_trip')
    old_monthly = pd.read_csv(SOURCE / 'portfolio_monthly.csv', float_precision='round_trip')
    descriptions = {
        'M1':('机构','Institutional holdings embedding → NN3','机构32维持仓Embedding → NN3'),
        'M2':('机构＋个人','Institutional + retail embeddings → NN3','机构32维＋个人64维 → 拼接 → NN3'),
        'M3':('公司Embedding','Firm characteristics embedding → NN3','公司输入32维 → 64 → Embedding32 → NN3'),
        'M4':('公司＋个人','Firm characteristics + retail embedding → NN3','公司Embedding32＋个人64维 → 拼接 → NN3'),
        'M5':('三路融合','Firm + institutional + retail embeddings → NN3','公司Embedding32＋机构32维＋个人64维 → 拼接 → NN3'),
    }
    models, all_rows, monthly_rows, period_metrics = [], [], [], {p:{} for p in frames}
    max_metric_error, max_monthly_error = 0., 0.
    for mode, spec in frozen['final'].items():
        c = spec['candidate']
        prediction = np.load(spec['prediction_file'])
        short, english, architecture = descriptions[mode]
        model = {'id':mode, 'name':short, 'english':english, 'architecture':architecture,
                 'family':c['family'], 'candidate_id':c['id'], 'params':c['params'],
                 'best_epochs':c['best_epochs'], 'calibration':spec['calibration'],
                 'validation_selection':c['validation'],
                 'code_path':str(CODE / 'tuning_models.py'), 'model_files':c['model_files'],
                 'periods':{}, 'monthly':{}}
        for period, frame in frames.items():
            rows, monthly = evaluate_group(frame, mode, prediction[masks[period]], factors, config)
            result = {}
            for row in rows:
                w = row['weighting']
                result[w] = {'gross':row['p10_p1_gross'], 'net':row['net_10bp'],
                    'r2':row['r2'], 'rank_ic':row['rank_ic'], 'alpha':row['ff3_alpha'],
                    'hac_t':row['ff3_alpha_t'], 'p1':row['p1_mean'], 'p10':row['p10_mean'],
                    'turnover':row['turnover'], 'months':row['months'], 'stock_months':row['n_test']}
                all_rows.append({'period':period, **row})
                if period == 'test':
                    previous = old_metrics[(old_metrics.group == mode) & (old_metrics.weighting == w)].iloc[0]
                    keys = ['p10_p1_gross','net_10bp','r2','rank_ic','ff3_alpha','ff3_alpha_t']
                    error = max(abs(float(row[k])-float(previous[k])) for k in keys)
                    max_metric_error = max(max_metric_error,error)
                    assert error < 1e-12, (mode,w,error)
            if period == 'test':
                keys = ['group','outcome_month','weighting']
                before = old_monthly[old_monthly.group == mode].sort_values(keys)
                after = monthly.sort_values(keys)
                cols = ['p1','p10','spread','turnover','net_spread']
                err = float(np.max(np.abs(before[cols].to_numpy()-after[cols].to_numpy())))
                max_monthly_error = max(max_monthly_error,err)
                assert err < 1e-12
            model['periods'][period] = result
            period_metrics[period][mode] = result
            model['monthly'][period] = monthly.to_dict('records')
            monthly.insert(0,'period',period)
            monthly_rows.extend(monthly.to_dict('records'))
        models.append(model)
    paired = []
    for period in frames:
        for w in ('EW','VW'):
            table = pd.DataFrame(monthly_rows)
            table = table[(table.period == period) & (table.weighting == w)]
            pivot = table.pivot(index='outcome_month',columns='group',values='spread')
            for check in rankings(period_metrics[period],w):
                delta = pivot[check['left']]-pivot[check['right']]
                mean,t = newey_west(delta.to_numpy(),None,3)
                paired.append({'period':period,'weighting':w,**check,'mean':mean,'hac_t':t,
                               'months':len(delta),'posthoc_opponent':check['left']=='M5'})
    history = json.loads((SOURCE/'historical_audit.json').read_text(encoding='utf-8'))
    legacy = verify_fingerprints(history['historical_files'])
    original_result = json.loads((SOURCE/'results.json').read_text(encoding='utf-8'))
    data = {'title':'五种信息模式 · Embedding + NN3',
        'generated_at':datetime.now(timezone(timedelta(hours=8))).isoformat(),
        'source_version':'outputs_tuning_20261008 · tuning_v1', 'source_dir':str(SOURCE),
        'reference_url':'https://aibot88.github.io/results-dashboard-tmp/rs-b-all-models/',
        'periods':{'train':'2016-10 — 2022-01','validation':'2022-02 — 2023-03','test':'2023-04 — 2024-12'},
        'models':models,'paired':paired,
        'rankings':{p:{w:rankings(period_metrics[p],w) for w in ('EW','VW')} for p in frames},
        'coverage':original_result['coverage'], 'runtime_seconds':original_result['runtime_seconds'],
        'fits':frozen['search']['completed_fits'], 'seeds':[42,43,44],
        'history_metrics':history['metrics'], 'freeze_verification':freeze_check,
        'audit':{'passed':True,'max_test_metric_error':max_metric_error,
                 'max_test_monthly_error':max_monthly_error,'legacy_files':legacy},
        'exploratory':True,'calibration_shrinkage_modes':['M1','M3','M4']}
    write_json(ROOT/'data.json',data)
    pd.DataFrame(all_rows).to_csv(ROOT/'metrics.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(monthly_rows).to_csv(ROOT/'monthly_returns.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(paired).to_csv(ROOT/'paired_differences.csv',index=False,encoding='utf-8-sig')
    shutil.copy2(SOURCE/'five_mode_summary.csv',ROOT/'five_mode_summary.csv')
    write_json(ROOT/'report_audit.json',data['audit'])
    template=(ROOT/'report.template.html').read_text(encoding='utf-8')
    embedded=json.dumps(clean(data),ensure_ascii=False,allow_nan=False).replace('</','<\\/')
    chart_library=(ROOT/'echarts.min.js').read_text(encoding='utf-8').replace('</script','<\\/script')
    page=template.replace('__CHART_LIBRARY__',chart_library).replace('__REPORT_DATA__',embedded)
    (ROOT/'index.html').write_text(page,encoding='utf-8')
    # Capture an immutable identity for all source artifacts used by this report.
    source_files=[SOURCE/name for name in ('metrics.csv','portfolio_monthly.csv','five_mode_summary.csv',
        'frozen_selection.json','frozen_selection.sha256.json','results.json','intersection.parquet','test_labels.parquet')]
    source_files += [Path(s['prediction_file']) for s in frozen['final'].values()]
    write_json(ROOT/'source_fingerprints.json',{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files})
    print(json.dumps({'models':len(models),'metric_rows':len(all_rows),'monthly_rows':len(monthly_rows),
                      'freeze':freeze_check,'audit':data['audit'],'output':str(ROOT/'index.html')},ensure_ascii=False))


if __name__ == '__main__':
    main()
